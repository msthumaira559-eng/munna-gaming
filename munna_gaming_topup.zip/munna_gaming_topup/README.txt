MUNNA GAMING Top-Up Website
============================

Files
- index.html: responsive dark/neon gaming top-up page with DLS/eFootball order form.

Important setup before publishing
1. Open index.html in a text editor.
2. Replace YOUR_EMAIL@example.com in the form action with the email address where you want to receive orders.
3. The first test submission to FormSubmit may require email verification. Check the inbox for the verification email.
4. Replace the placeholder payment instructions with your verified bKash/Nagad number and clear instructions. Never publish someone else's number.
5. Set package prices and exact delivery details before accepting payments.
6. Do not request PIN, OTP, game password, or recovery codes.

Run locally in Termux
  pkg update
  pkg install python nano
  mkdir -p ~/gaming-site
  cd ~/gaming-site
Copy index.html into this folder, then:
  python -m http.server 8080
Open http://127.0.0.1:8080 in your phone browser.

Online hosting
- You can publish the static site with GitHub Pages.
- Create a public repository, upload index.html, then Settings > Pages > Deploy from a branch > main > /(root) > Save.
- Wait for GitHub Pages to publish the site.
- FormSubmit is a third-party form relay; it is not a payment processor. Confirm its current terms/privacy before use. Orders are manual; this page does not automatically add coins or verify payments.
